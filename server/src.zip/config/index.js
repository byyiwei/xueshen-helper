/**
 * 服务器配置
 * 优先级：环境变量 > 默认值
 */
module.exports = {
  // 服务器
  port: parseInt(process.env.PORT, 10) || 3000,
  host: process.env.HOST || '0.0.0.0',

  // 数据库
  db: {
    host: process.env.DB_HOST || '127.0.0.1',
    port: parseInt(process.env.DB_PORT, 10) || 3306,
    user: process.env.DB_USER || 'turtle-records',
    password: process.env.DB_PASSWORD || '199975yiwei',
    database: process.env.DB_NAME || 'turtle-records',
    charset: 'utf8mb4',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  },

  // JWT
  jwt: {
    secret: process.env.JWT_SECRET || 'DBpxjbHQG3TrZhWRCpHr6iGtgsVePIqhvZKZ3edaBs4=',
    adminSecret: process.env.ADMIN_JWT_SECRET || 'turtle-admin-2024-secure-key-x9kM2vLpQr7',
    expiresIn: process.env.JWT_EXPIRES || '30d'
  },

  // 微信小程序
  wechat: {
    appId: process.env.WECHAT_APPID || '',
    appSecret: process.env.WECHAT_APPSECRET || '',
    // 消息推送配置（非审核回调，备用）
    token: process.env.WECHAT_TOKEN || '199975yiwei',
    encodingAESKey: process.env.WECHAT_AES_KEY || 'oQrWmlgUecX17Z9JqhdyAUPpTgh8H8p5XwiBkyR8rBw'
  },

  // 国密 SM2 非对称加密（预留）
  sm2: {
    publicKey: process.env.SM2_PUBLIC_KEY || ''
  },

  // 图片上传
  upload: {
    baseDir: process.env.UPLOAD_DIR || 'uploads',
    maxFileSize: 20 * 1024 * 1024, // 20MB
    allowedTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
  },

  // 公开资源基础URL（前端拼接用）
  baseUrl: process.env.BASE_URL || 'https://pets.openget.cn'
}
