/**
 * 龟缸管理路由
 * - 公开接口: /api/tanks
 * - 管理接口: /api/tanks/admin
 */
const express = require('express')
const router = express.Router()
const { query, getOne, insert, execute } = require('../services/db')
const { requireAdminAuth } = require('../middleware/admin-auth')
const { requireAuth, requireAdmin } = require('../middleware/auth')
const { success, error, listResult } = require('../utils/response')

// ==================== 公开接口 ====================

/** GET /api/tanks - 龟缸列表 */
router.get('/', async (req, res) => {
  try {
    const rows = await query(
      'SELECT id, name, size, location, setup_date, male_count, female_count, notes FROM tanks WHERE enabled = 1 ORDER BY sort_order ASC, id ASC'
    )
    return res.json(success(rows))
  } catch (err) {
    console.error('[Tank] GET /api/tanks error:', err)
    return res.json(error('获取龟缸列表失败'))
  }
})

/** GET /api/tanks/stats - 统计数据 */
router.get('/stats', async (req, res) => {
  try {
    const tanks = await query('SELECT id, name, male_count, female_count FROM tanks WHERE enabled = 1')
    const count = tanks.length
    const totalMale = tanks.reduce((s, t) => s + (t.male_count || 0), 0)
    const totalFemale = tanks.reduce((s, t) => s + (t.female_count || 0), 0)
    return res.json(success({ count, totalMale, totalFemale, tanks }))
  } catch (err) {
    console.error('[Tank] GET /api/tanks/stats error:', err)
    return res.json(error('获取统计失败'))
  }
})

/** POST /api/tanks - 小程序端新增龟缸（需登录） */
router.post('/', requireAuth, async (req, res) => {
  try {
    const { name, size, location, setup_date, male_count, female_count, notes, sort_order } = req.body
    if (!name) {
      return res.json(error('请输入龟缸名称'))
    }
    const id = await insert(
      'INSERT INTO tanks (name, size, location, setup_date, male_count, female_count, notes, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [name, size || '', location || '', setup_date || null, male_count || 0, female_count || 0, notes || '', sort_order || 0]
    )
    return res.json(success({ id }, '龟缸已添加'))
  } catch (err) {
    console.error('[Tank] POST /api/tanks error:', err)
    return res.json(error('添加龟缸失败'))
  }
})

// ==================== 管理接口（必须在 /:id 之前注册，否则会被通配路由拦截） ====================
router.use('/admin', requireAdminAuth)

/** GET /api/tanks/admin - 后台列表(含禁用) */
router.get('/admin', async (req, res) => {
  try {
    const { pageNum = 1, pageSize = 20, search } = req.query
    const conditions = ['1=1']
    const params = []
    if (search) { conditions.push('(name LIKE ? OR location LIKE ?)'); params.push(`%${search}%`, `%${search}%`) }
    const where = conditions.join(' AND ')
    const [countRows] = await (await query(`SELECT COUNT(*) AS total FROM tanks WHERE ${where}`, params))
    const rows = await query(
      `SELECT * FROM tanks WHERE ${where} ORDER BY sort_order ASC, id ASC LIMIT ${parseInt(pageSize)} OFFSET ${(parseInt(pageNum) - 1) * parseInt(pageSize)}`,
      params
    )
    return res.json(listResult(rows, countRows.total, parseInt(pageNum), parseInt(pageSize)))
  } catch (err) {
    console.error('[Tank] Admin list error:', err)
    return res.json(error('获取列表失败'))
  }
})

/** POST /api/tanks/admin - 新增 */
router.post('/admin', async (req, res) => {
  try {
    const { name, size, location, setup_date, male_count, female_count, notes, sort_order } = req.body
    const id = await insert(
      'INSERT INTO tanks (name, size, location, setup_date, male_count, female_count, notes, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [name, size || '', location || '', setup_date || null, male_count || 0, female_count || 0, notes || '', sort_order || 0]
    )
    return res.json(success({ id }, '龟缸已添加'))
  } catch (err) {
    console.error('[Tank] Admin create error:', err)
    return res.json(error('添加龟缸失败'))
  }
})

/** PUT /api/tanks/admin/:id - 编辑 */
router.put('/admin/:id', async (req, res) => {
  try {
    const { name, size, location, setup_date, male_count, female_count, notes, enabled, sort_order } = req.body
    await execute(
      'UPDATE tanks SET name=?, size=?, location=?, setup_date=?, male_count=?, female_count=?, notes=?, enabled=?, sort_order=? WHERE id=?',
      [name, size || '', location || '', setup_date || null, male_count || 0, female_count || 0, notes || '', enabled !== false ? 1 : 0, sort_order || 0, req.params.id]
    )
    return res.json(success(null, '龟缸已更新'))
  } catch (err) {
    console.error('[Tank] Admin update error:', err)
    return res.json(error('更新龟缸失败'))
  }
})

/** DELETE /api/tanks/admin/:id - 删除 */
router.delete('/admin/:id', async (req, res) => {
  try {
    await execute('DELETE FROM tanks WHERE id = ?', [req.params.id])
    return res.json(success(null, '龟缸已删除'))
  } catch (err) {
    console.error('[Tank] Admin delete error:', err)
    return res.json(error('删除龟缸失败'))
  }
})

/** POST /api/tanks/admin/batch-delete - 批量删除 */
router.post('/admin/batch-delete', async (req, res) => {
  try {
    const { ids } = req.body
    if (!ids || !ids.length) return res.json(error('请选择要删除的龟缸'))
    await execute(`DELETE FROM tanks WHERE id IN (${ids.map(() => '?').join(',')})`, ids)
    return res.json(success(null, `已删除 ${ids.length} 个龟缸`))
  } catch (err) {
    console.error('[Tank] Batch delete error:', err)
    return res.json(error('批量删除失败'))
  }
})

// ==================== 参数路由（/:id 系列必须放在 /admin 等固定路由之后） ====================

/** GET /api/tanks/:id - 龟缸详情 */
router.get('/:id', async (req, res) => {
  try {
    const tank = await getOne(
      'SELECT id, name, size, location, setup_date, male_count, female_count, notes FROM tanks WHERE id = ? AND enabled = 1',
      [req.params.id]
    )
    if (!tank) return res.json(error('龟缸不存在'))

    // 种群比例
    const total = (tank.male_count || 0) + (tank.female_count || 0)
    tank.ratio = total > 0 ? `${tank.male_count}:${tank.female_count}` : '-'

    return res.json(success(tank))
  } catch (err) {
    console.error('[Tank] GET /api/tanks/:id error:', err)
    return res.json(error('获取龟缸详情失败'))
  }
})

/** GET /api/tanks/:id/timeline - 时间线 */
router.get('/:id/timeline', async (req, res) => {
  try {
    const tankId = req.params.id
    const items = []

    const water = await query(
      "SELECT id, 'water' AS type, record_date, CONCAT('换水 ', water_change) AS title, notes FROM tank_water_records WHERE tank_id = ? ORDER BY record_date DESC LIMIT 50",
      [tankId]
    )
    water.forEach(r => items.push({ ...r, date: r.record_date }))

    const feeding = await query(
      "SELECT id, 'feeding' AS type, record_date, CONCAT('喂食 ', food_type) AS title, CONCAT(amount_g, 'g') AS detail, notes FROM tank_feeding_records WHERE tank_id = ? ORDER BY record_date DESC LIMIT 50",
      [tankId]
    )
    feeding.forEach(r => items.push({ ...r, date: r.record_date }))

    const eggs = await query(
      "SELECT id, 'egg' AS type, lay_date AS record_date, CONCAT('产蛋 ', total_eggs, '枚') AS title, CONCAT('受精', fertilized, '/未受精', unfertilized) AS detail, notes FROM tank_egg_records WHERE tank_id = ? ORDER BY lay_date DESC LIMIT 50",
      [tankId]
    )
    eggs.forEach(r => items.push({ ...r, date: r.record_date, record_date: r.record_date }))

    items.sort((a, b) => new Date(b.date) - new Date(a.date))

    return res.json(success(items.slice(0, 50)))
  } catch (err) {
    console.error('[Tank] GET /api/tanks/:id/timeline error:', err)
    return res.json(error('获取时间线失败'))
  }
})

// ==================== 换水记录 ====================

/** GET /api/tanks/:id/water */
router.get('/:id/water', async (req, res) => {
  try {
    const rows = await query(
      'SELECT id, record_date, water_change, notes, created_at FROM tank_water_records WHERE tank_id = ? ORDER BY record_date DESC',
      [req.params.id]
    )
    return res.json(success(rows))
  } catch (err) {
    console.error('[Tank] GET water error:', err)
    return res.json(error('获取换水记录失败'))
  }
})

/** POST /api/tanks/:id/water */
router.post('/:id/water', async (req, res) => {
  try {
    const { record_date, water_change, notes } = req.body
    const id = await insert(
      'INSERT INTO tank_water_records (tank_id, record_date, water_change, notes) VALUES (?, ?, ?, ?)',
      [req.params.id, record_date || new Date().toISOString().slice(0, 10), water_change || '', notes || '']
    )
    return res.json(success({ id }, '换水记录已添加'))
  } catch (err) {
    console.error('[Tank] POST water error:', err)
    return res.json(error('添加换水记录失败'))
  }
})

// ==================== 喂食记录 ====================

/** GET /api/tanks/:id/feeding */
router.get('/:id/feeding', async (req, res) => {
  try {
    const rows = await query(
      'SELECT id, record_date, food_type, amount_g, additives, notes, created_at FROM tank_feeding_records WHERE tank_id = ? ORDER BY record_date DESC',
      [req.params.id]
    )
    return res.json(success(rows))
  } catch (err) {
    console.error('[Tank] GET feeding error:', err)
    return res.json(error('获取喂食记录失败'))
  }
})

/** POST /api/tanks/:id/feeding */
router.post('/:id/feeding', async (req, res) => {
  try {
    const { record_date, food_type, amount_g, additives, notes } = req.body
    const id = await insert(
      'INSERT INTO tank_feeding_records (tank_id, record_date, food_type, amount_g, additives, notes) VALUES (?, ?, ?, ?, ?, ?)',
      [req.params.id, record_date || new Date().toISOString().slice(0, 10), food_type || '', amount_g || null, additives || '', notes || '']
    )
    return res.json(success({ id }, '喂食记录已添加'))
  } catch (err) {
    console.error('[Tank] POST feeding error:', err)
    return res.json(error('添加喂食记录失败'))
  }
})

// ==================== 产蛋记录 ====================

/** GET /api/tanks/:id/eggs */
router.get('/:id/eggs', async (req, res) => {
  try {
    const rows = await query(
      'SELECT id, tank_id, lay_date, total_eggs, fertilized, unfertilized, parent_male, parent_female, notes, created_at FROM tank_egg_records WHERE tank_id = ? ORDER BY lay_date DESC',
      [req.params.id]
    )
    // 附加受精率计算 + 孵化记录
    for (const r of rows) {
      r.fertility_rate = r.total_eggs > 0 ? ((r.fertilized / r.total_eggs) * 100).toFixed(1) + '%' : '-'
      const hatch = await query(
        'SELECT id, hatch_date, total_hatched, perfect_count, imperfect_count FROM tank_hatch_records WHERE egg_record_id = ?',
        [r.id]
      )
      r.hatch_records = hatch.map(h => ({
        ...h,
        perfect_rate: h.total_hatched > 0 ? ((h.perfect_count / h.total_hatched) * 100).toFixed(1) + '%' : '-'
      }))
    }
    return res.json(success(rows))
  } catch (err) {
    console.error('[Tank] GET eggs error:', err)
    return res.json(error('获取产蛋记录失败'))
  }
})

/** POST /api/tanks/:id/eggs */
router.post('/:id/eggs', async (req, res) => {
  try {
    const { lay_date, total_eggs, fertilized, unfertilized, parent_male, parent_female, notes } = req.body
    const id = await insert(
      'INSERT INTO tank_egg_records (tank_id, lay_date, total_eggs, fertilized, unfertilized, parent_male, parent_female, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [req.params.id, lay_date || new Date().toISOString().slice(0, 10), total_eggs || 0, fertilized || 0, unfertilized || 0, parent_male || '', parent_female || '', notes || '']
    )
    return res.json(success({ id }, '产蛋记录已添加'))
  } catch (err) {
    console.error('[Tank] POST egg error:', err)
    return res.json(error('添加产蛋记录失败'))
  }
})

// ==================== 孵化记录 ====================

/** GET /api/tanks/:id/eggs/:eggId/hatch */
router.get('/:id/eggs/:eggId/hatch', async (req, res) => {
  try {
    const rows = await query(
      'SELECT id, hatch_date, total_hatched, perfect_count, imperfect_count, notes, created_at FROM tank_hatch_records WHERE egg_record_id = ? ORDER BY hatch_date DESC',
      [req.params.eggId]
    )
    for (const r of rows) {
      r.perfect_rate = r.total_hatched > 0 ? ((r.perfect_count / r.total_hatched) * 100).toFixed(1) + '%' : '-'
    }
    return res.json(success(rows))
  } catch (err) {
    console.error('[Tank] GET hatch error:', err)
    return res.json(error('获取孵化记录失败'))
  }
})

/** POST /api/tanks/:id/eggs/:eggId/hatch */
router.post('/:id/eggs/:eggId/hatch', async (req, res) => {
  try {
    const { hatch_date, total_hatched, perfect_count, imperfect_count, notes } = req.body
    const id = await insert(
      'INSERT INTO tank_hatch_records (egg_record_id, hatch_date, total_hatched, perfect_count, imperfect_count, notes) VALUES (?, ?, ?, ?, ?, ?)',
      [req.params.eggId, hatch_date || new Date().toISOString().slice(0, 10), total_hatched || 0, perfect_count || 0, imperfect_count || 0, notes || '']
    )
    return res.json(success({ id }, '孵化记录已添加'))
  } catch (err) {
    console.error('[Tank] POST hatch error:', err)
    return res.json(error('添加孵化记录失败'))
  }
})

// ==================== 提醒设置 ====================

/** GET /api/tanks/:id/reminders */
router.get('/:id/reminders', async (req, res) => {
  try {
    const rows = await query(
      'SELECT id, type, interval_days, next_remind, last_remind, event_name, event_date, enabled FROM tank_reminders WHERE tank_id = ?',
      [req.params.id]
    )
    return res.json(success(rows))
  } catch (err) {
    console.error('[Tank] GET reminders error:', err)
    return res.json(error('获取提醒设置失败'))
  }
})

/** PUT /api/tanks/:id/reminders */
router.put('/:id/reminders', async (req, res) => {
  try {
    const items = req.body.items || []
    // 先删后插
    await execute('DELETE FROM tank_reminders WHERE tank_id = ?', [req.params.id])
    for (const item of items) {
      await insert(
        'INSERT INTO tank_reminders (tank_id, type, interval_days, next_remind, event_name, event_date, enabled) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [req.params.id, item.type, item.interval_days || 0, item.next_remind || null, item.event_name || '', item.event_date || null, item.enabled !== false ? 1 : 0]
      )
    }
    return res.json(success(null, '提醒设置已更新'))
  } catch (err) {
    console.error('[Tank] PUT reminders error:', err)
    return res.json(error('更新提醒设置失败'))
  }
})

// ==================== 快速打卡 ====================

/** POST /api/tanks/:id/check - 快捷打卡 (water/feeding) */
router.post('/:id/check', async (req, res) => {
  try {
    const { type, record_date, water_change, food_type, amount_g } = req.body
    const date = record_date || new Date().toISOString().slice(0, 10)

    if (type === 'water') {
      await insert(
        'INSERT INTO tank_water_records (tank_id, record_date, water_change) VALUES (?, ?, ?)',
        [req.params.id, date, water_change || '1/3']
      )
      // 更新提醒
      await execute(
        "UPDATE tank_reminders SET last_remind = ?, next_remind = DATE_ADD(?, INTERVAL interval_days DAY) WHERE tank_id = ? AND type = 'water' AND enabled = 1",
        [date, date, req.params.id]
      )
    } else if (type === 'feeding') {
      await insert(
        'INSERT INTO tank_feeding_records (tank_id, record_date, food_type, amount_g) VALUES (?, ?, ?, ?)',
        [req.params.id, date, food_type || '', amount_g || null]
      )
      await execute(
        "UPDATE tank_reminders SET last_remind = ?, next_remind = DATE_ADD(?, INTERVAL interval_days DAY) WHERE tank_id = ? AND type = 'feed' AND enabled = 1",
        [date, date, req.params.id]
      )
    }
    return res.json(success(null, '打卡成功'))
  } catch (err) {
    console.error('[Tank] POST check error:', err)
    return res.json(error('打卡失败'))
  }
})

module.exports = router
